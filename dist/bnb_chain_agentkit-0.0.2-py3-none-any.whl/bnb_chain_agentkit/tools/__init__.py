"""BNB Chain Tool."""

from bnb_chain_agentkit.tools.bnb_chain_tool import BnbChainTool

__all__ = ['BnbChainTool']
