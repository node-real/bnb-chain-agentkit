from bnb_chain_agentkit.__version__ import __version__

__all__ = ['__version__']
